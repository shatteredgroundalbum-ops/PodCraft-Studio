import React, { useCallback, useEffect, useState, useRef } from 'react';
import { Sliders } from 'lucide-react';
import { StudioProvider, useStudio } from './contexts/StudioContext';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { ScriptPanel } from './components/ScriptPanel';
import { Recorder } from './components/Recorder';
import { AIProducer } from './components/AIProducer';
import { Transport } from './components/Transport';
import { Mixer } from './components/Mixer';
function StudioPage() {
  const { mixerOpen, setMixerOpen } = useStudio();
  const [scriptHeight, setScriptHeight] = useState(300);
  const [aiWidth, setAiWidth] = useState(360);
  const [aiCollapsed, setAiCollapsed] = useState(false);
  // Vertical resizer for Script <-> Recorder
  const scriptDragRef = useRef<{
    active: boolean;
    startY: number;
    startH: number;
  }>({
    active: false,
    startY: 0,
    startH: 0
  });
  const handleScriptResizeDown = (e: React.PointerEvent) => {
    e.preventDefault();
    scriptDragRef.current = {
      active: true,
      startY: e.clientY,
      startH: scriptHeight
    };
  };
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (!scriptDragRef.current.active) return;
      const delta = e.clientY - scriptDragRef.current.startY;
      const next = Math.max(
        120,
        Math.min(700, scriptDragRef.current.startH + delta)
      );
      setScriptHeight(next);
    };
    const onUp = () => {
      scriptDragRef.current.active = false;
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
  }, []);
  // Horizontal resizer for AI panel
  const aiDragRef = useRef<{
    active: boolean;
    startX: number;
    startW: number;
  }>({
    active: false,
    startX: 0,
    startW: 0
  });
  const handleAiResizeDown = (e: React.PointerEvent) => {
    e.preventDefault();
    aiDragRef.current = {
      active: true,
      startX: e.clientX,
      startW: aiWidth
    };
  };
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (!aiDragRef.current.active) return;
      const delta = aiDragRef.current.startX - e.clientX;
      const next = Math.max(
        260,
        Math.min(640, aiDragRef.current.startW + delta)
      );
      setAiWidth(next);
    };
    const onUp = () => {
      aiDragRef.current.active = false;
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
  }, []);
  const toggleAiCollapsed = useCallback(() => setAiCollapsed((c) => !c), []);
  return (
    <div className="flex w-full h-screen bg-gray-50 overflow-hidden font-sans text-gray-900">
      <Sidebar />

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar />

        <div className="flex-1 flex overflow-hidden min-h-0">
          {/* Center column: scrollable */}
          <div className="flex-1 flex flex-col min-w-0 overflow-y-auto p-4 gap-0">
            <ScriptPanel height={scriptHeight} />

            {/* Vertical resize handle */}
            <div
              onPointerDown={handleScriptResizeDown}
              className="h-2 my-1 flex items-center justify-center cursor-row-resize group flex-shrink-0"
              style={{
                touchAction: 'none'
              }}>
              
              <div className="w-12 h-1 bg-gray-300 rounded-full group-hover:bg-violet-500 transition-colors"></div>
            </div>

            <Recorder />
          </div>

          {/* AI Panel resizer */}
          {!aiCollapsed &&
          <div
            onPointerDown={handleAiResizeDown}
            className="w-1.5 cursor-col-resize bg-transparent hover:bg-violet-300 transition-colors flex-shrink-0"
            style={{
              touchAction: 'none'
            }} />

          }

          <AIProducer
            width={aiWidth}
            collapsed={aiCollapsed}
            onToggleCollapsed={toggleAiCollapsed} />
          
        </div>

        <Transport />
      </div>

      <Mixer />

      {/* Floating Mixer Toggle (only shows when mixer is closed) */}
      {!mixerOpen &&
      <button
        onClick={() => setMixerOpen(true)}
        className="fixed bottom-28 right-6 z-[90] flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-3 rounded-full shadow-xl shadow-violet-600/30 transition-all hover:scale-105"
        title="Open Mixer">
        
          <Sliders className="w-5 h-5" />
          <span className="text-sm font-semibold">Open Mixer</span>
        </button>
      }
    </div>);

}
export function App() {
  return (
    <StudioProvider>
      <StudioPage />
    </StudioProvider>);

}