export const manifest = {
  screens: {
    scr_kpbx5f: { name: "Studio", route: "/" }
  }
};