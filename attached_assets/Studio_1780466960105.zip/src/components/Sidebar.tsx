import React from 'react';
import {
  Home,
  Folder,
  Calendar,
  CheckSquare,
  LayoutTemplate,
  Image,
  Mic,
  Sparkles,
  BarChart2,
  Users,
  Settings } from
'lucide-react';
const navItems = [
{
  icon: Home,
  label: 'Dashboard'
},
{
  icon: Folder,
  label: 'Projects'
},
{
  icon: Calendar,
  label: 'Calendar'
},
{
  icon: CheckSquare,
  label: 'Tasks'
},
{
  icon: LayoutTemplate,
  label: 'Templates'
},
{
  icon: Image,
  label: 'Media Library'
},
{
  icon: Mic,
  label: 'Studio',
  active: true
},
{
  icon: Sparkles,
  label: 'AI Producer'
},
{
  icon: BarChart2,
  label: 'Analytics'
},
{
  icon: Users,
  label: 'Team'
}];

export function Sidebar() {
  return (
    <div className="w-[240px] h-full bg-white border-r border-gray-200 flex flex-col flex-shrink-0">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center text-white font-bold">
          <div className="flex gap-0.5 items-end h-4">
            <div className="w-0.5 h-2 bg-white rounded-full"></div>
            <div className="w-0.5 h-4 bg-white rounded-full"></div>
            <div className="w-0.5 h-3 bg-white rounded-full"></div>
            <div className="w-0.5 h-1.5 bg-white rounded-full"></div>
          </div>
        </div>
        <span className="font-bold text-xl text-gray-900 tracking-tight">
          PodCraft
          <br />
          <span className="text-sm font-medium text-gray-500 leading-none block">
            Central
          </span>
        </span>
      </div>

      <div className="px-4 mb-6">
        <button className="w-full bg-violet-600 hover:bg-violet-700 text-white rounded-lg py-2.5 px-4 flex items-center justify-center gap-2 font-medium transition-colors">
          <span className="text-lg leading-none">+</span> New Project
        </button>
      </div>

      <nav className="flex-1 overflow-hidden px-3 space-y-1">
        {navItems.map((item, i) =>
        <button
          key={i}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${item.active ? 'bg-violet-50 text-violet-700 relative' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}`}>
          
            {item.active &&
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-violet-600 rounded-r-full"></div>
          }
            <item.icon
            className={`w-5 h-5 ${item.active ? 'text-violet-600' : 'text-gray-400'}`} />
          
            {item.label}
          </button>
        )}
      </nav>

      <div className="p-4 border-t border-gray-100 space-y-4">
        <button className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 w-full">
          <Settings className="w-5 h-5 text-gray-400" />
          Settings
        </button>

        <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full bg-green-500"></div>
            <span className="text-xs font-medium text-gray-700">
              openDAW ready
            </span>
          </div>
          <span className="text-xs text-gray-500 ml-4">v1.0.0</span>
        </div>
      </div>
    </div>);

}